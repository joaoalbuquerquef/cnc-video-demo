/* Semana FICTICIA para os prototipos (nenhum valor, nome ou caminho real).
   Mesmo formato de GET /api/estado do servidor atual (interface/servidor.py: Estado.visao) + dois campos que os
   prototipos propoem: "historico" (funcionalidade A8 do catalogo) e "checklist" (A7). */
window.DADOS = {
  semana: "2026-11-09", rotulo: "09.11 a 13.11", ficticio: true,
  pastas: { rm: "C:\\exemplo\\coleta\\rm", semanal: "C:\\exemplo\\Semanal\\2026", saida: "C:\\exemplo\\saida" },
  relatorios: [
    { id: "rendimento", titulo: "Rendimento", acao: "gerar", disponivel: true,
      explicacao: "PDF gerado da DISPON SEMANAL, relido e comparado linha a linha com o impresso.",
      insumos: [
        { id: "aplicacoes", nome: "Aplicações Financeiras (DISPON SEMANAL)", status: "achado", origem: "copia semanal", caminhos: ["C:\\exemplo\\coleta\\aplicacoes\\Aplicacoes_2026-11-13.xlsx"], detalhe: "data-base 13/11" },
        { id: "pdf_rendimento", nome: "PDF impresso (gabarito)", status: "achado", origem: "rede", caminhos: ["C:\\exemplo\\Semanal\\Rendimento - 09.11 a 13.11 - Atualizado.pdf"], detalhe: "" } ],
      ultima: { estado: "pronto", segundos: 6.2, resumo: { fecha: true, linhas: [113, 113], unidade: "linhas iguais", alertas: 0, pdf: "Rendimento - 09.11 a 13.11.pdf" } } },
    { id: "movimentacao", titulo: "Movimentação da Carteira", acao: "gerar", disponivel: true,
      explicacao: "PDF gerado do extrato do RM (04.015), relido e comparado com o impresso.",
      insumos: [
        { id: "rm", nome: "Exportações do RM", status: "achado", origem: "pasta do RM", caminhos: ["C:\\exemplo\\coleta\\rm\\extrato_09-13_11.XLS", "C:\\exemplo\\coleta\\rm\\lancamentos_09-13_11.XLS"], detalhe: "2 arquivos" },
        { id: "pdf_movimentacao", nome: "PDF impresso (gabarito)", status: "achado", origem: "rede", caminhos: ["C:\\exemplo\\Semanal\\Movimentacao da Carteira - 09.11 a 13.11.pdf"], detalhe: "" } ],
      ultima: { estado: "pronto", segundos: 3.4, resumo: { fecha: true, linhas: [17, 17], unidade: "linhas iguais", alertas: 0, pdf: "Movimentacao - 09.11 a 13.11.pdf" } } },
    { id: "pagamentos", titulo: "Pagamentos", acao: "gerar", disponivel: true,
      explicacao: "Totais por dia da regra v3; PDF em versão de demonstração (nomes do RM).",
      insumos: [
        { id: "rm", nome: "Exportações do RM", status: "achado", origem: "pasta do RM", caminhos: ["C:\\exemplo\\coleta\\rm\\lancamentos_09-13_11.XLS"], detalhe: "" },
        { id: "pdf_pagamentos", nome: "PDF impresso (gabarito)", status: "achado", origem: "rede", caminhos: ["C:\\exemplo\\Semanal\\Pagamentos - 09.11 a 13.11.pdf"], detalhe: "" } ],
      ultima: { estado: "pronto", segundos: 8.9, resumo: { fecha: true, verificacoes: [5, 5], unidade: "dias iguais", nota: "344/393 linhas iguais; diferenças só de nome (demonstração)", alertas: 0, pdf: "Pagamentos - 09.11 a 13.11.pdf" } } },
    { id: "recebimentos", titulo: "Recebimentos", acao: "gerar", disponivel: true,
      explicacao: "Totais por dia e quadro da regra v1; o que foi digitado à mão vira aviso da semana.",
      insumos: [
        { id: "rm", nome: "Exportações do RM", status: "achado", origem: "pasta do RM", caminhos: ["C:\\exemplo\\coleta\\rm\\lancamentos_09-13_11.XLS"], detalhe: "" },
        { id: "pdf_recebimentos", nome: "PDF impresso (gabarito)", status: "achado", origem: "rede", caminhos: ["C:\\exemplo\\Semanal\\Recebimentos - 09.11 a 13.11.pdf"], detalhe: "" } ],
      ultima: { estado: "pronto", segundos: 7.1, resumo: { fecha: false, verificacoes: [40, 43], unidade: "campos iguais", alertas: 2, pdf: "Recebimentos - 09.11 a 13.11.pdf",
        avisos: { linhas: 3, texto: "Crédito a classificar em 11/11 na conta 00XX: R$ 1.234,56 (exemplo)\nAvulso em 12/11 (aluguel de exemplo): R$ 2.000,00\nBaixa diferente do depósito em 13/11: diferença de R$ 10,00" } } } },
    { id: "semanal", titulo: "Relatório Semanal", acao: "gerar", disponivel: true,
      explicacao: "PDF gerado do RM e da DISPON SEMANAL, relido e comparado campo a campo com o impresso.",
      insumos: [
        { id: "rm", nome: "Exportações do RM", status: "achado", origem: "pasta do RM", caminhos: ["C:\\exemplo\\coleta\\rm\\extrato_09-13_11.XLS"], detalhe: "" },
        { id: "aplicacoes", nome: "Aplicações Financeiras (DISPON SEMANAL)", status: "achado", origem: "copia semanal", caminhos: ["C:\\exemplo\\coleta\\aplicacoes\\Aplicacoes_2026-11-13.xlsx"], detalhe: "" },
        { id: "dash", nome: "Dash_Relatório Semanal.xlsx", status: "faltando", origem: "", caminhos: [], detalhe: "necessário para as linhas digitadas" },
        { id: "pdf_semanal", nome: "PDF impresso (gabarito)", status: "achado", origem: "rede", caminhos: ["C:\\exemplo\\Semanal\\Relatorio Semanal - 09.11 a 13.11.pdf"], detalhe: "" } ],
      ultima: { estado: "pronto", segundos: 12.5, resumo: { fecha: false, linhas: [45, 54], unidade: "campos iguais", alertas: 1, pdf: "Relatorio Semanal - 09.11 a 13.11.pdf" } } }
  ],
  checklist: [
    { dia: "Segunda", passo: "Exportar lançamentos e extrato do RM", quem: "Financeiro", feito: true, quando: "seg 10:20" },
    { dia: "Segunda", passo: "Lançar no RM o que movimentou banco na semana", quem: "Tesouraria", feito: true, quando: "seg 12:00" },
    { dia: "Sexta", passo: "Guardar a Aplicações Financeiras da sexta", quem: "automático", feito: true, quando: "sex 17:05" },
    { dia: "Segunda", passo: "Conferir os 5 relatórios", quem: "Financeiro", feito: true, quando: "seg 14:10" },
    { dia: "Segunda", passo: "Resolver os avisos da semana", quem: "Tesouraria", feito: false, quando: "" },
    { dia: "Segunda", passo: "Enviar o pacote da semana", quem: "Financeiro", feito: false, quando: "" }
  ],
  historico: [
    { semana: "21.09 a 25.09", rend: 100, mov: 100, pag: 100, rec: 95, sem: 80 },
    { semana: "28.09 a 02.10", rend: 100, mov: 100, pag: 100, rec: 93, sem: 78 },
    { semana: "05.10 a 09.10", rend: 100, mov: 100, pag: 100, rec: 100, sem: 81 },
    { semana: "12.10 a 16.10", rend: 100, mov: 100, pag: 100, rec: 96, sem: 83 },
    { semana: "19.10 a 23.10", rend: 100, mov: 100, pag: 100, rec: 90, sem: 80 },
    { semana: "26.10 a 30.10", rend: 100, mov: 100, pag: 100, rec: 97, sem: 85 },
    { semana: "02.11 a 06.11", rend: 100, mov: 100, pag: 100, rec: 93, sem: 83 },
    { semana: "09.11 a 13.11", rend: 100, mov: 100, pag: 100, rec: 93, sem: 83 }
  ]
};
