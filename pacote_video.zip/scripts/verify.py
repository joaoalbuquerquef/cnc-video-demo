import json,pathlib,subprocess
out=pathlib.Path('output');report=[]
expected={'cnc_relatorios_60s.mp4':60,'cnc_relatorios_2min.mp4':165,'teste_12s.mp4':12}
files=list(out.glob('*.mp4'));assert files,'Nenhum MP4 produzido'
for p in files:
 info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)],text=True))
 v=info['streams'][0];assert len(info['streams'])==1
 assert (v['codec_name'],v['width'],v['height'],v['r_frame_rate'])==('h264',1920,1080,'30/1')
 assert abs(float(info['format']['duration'])-expected[p.name])<.1
 frames=out/'revisao'/p.stem;frames.mkdir(parents=True,exist_ok=True)
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-i',str(p),'-vf','fps=1/5',str(frames/'quadro_%03d.png')],check=True)
 report.append({'arquivo':p.name,'duracao':info['format']['duration'],'codec':v['codec_name'],'resolucao':'1920x1080','fps':30,'audio':False,'quadros_para_revisao':len(list(frames.glob('*.png')))})
(out/'verificacao.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
(out/'LEIA-ME.txt').write_text('Gravação de navegação em protótipos com dados fictícios.\nA animação do botão Gerar todos é demonstrativa; não executa o aplicativo Python nem gera PDFs financeiros.\nRevise os quadros na pasta revisao antes de apresentar. A validação automática verifica o formato, não certifica o conteúdo visual.\nO arquivo cnc_relatorios_2min.mp4, quando solicitado, tem 2min45s.\nSem áudio; legendas também disponíveis em SRT.\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
