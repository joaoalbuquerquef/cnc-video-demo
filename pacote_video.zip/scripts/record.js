'use strict';
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');
const mode = process.argv[2] || '60s';
if (!['60s','completo','ambos','teste'].includes(mode)) throw Error('Modo inválido');
const plans = JSON.parse(fs.readFileSync('scenes.json','utf8'));
const plan = mode==='teste' ? plans.test : mode==='60s' ? plans.short : plans.full;
const sleep = ms => new Promise(r=>setTimeout(r,ms));
(async()=>{
 fs.mkdirSync('build/raw',{recursive:true});fs.mkdirSync('output',{recursive:true});
 const browser=await chromium.launch({headless:true});
 try {
  for (const [scene,seconds] of plan) {
   const context=await browser.newContext({viewport:{width:1920,height:1080},deviceScaleFactor:1,colorScheme:'light',recordVideo:{dir:path.resolve('build/raw'),size:{width:1920,height:1080}}});
   const errors=[];const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
   // The prototype and its fonts are local. There is no access to RM or CNC systems.
   await context.route(/^https?:/,route=>route.abort());
   await page.goto(pathToFileURL(path.resolve(`build/scene${scene}.html`)).href);
   await page.evaluate(()=>document.fonts.ready);
   if(await page.locator('.badge').textContent()!=='Dados fictícios') throw Error('Selo ausente');
   const frame=page.frames().find(f=>f!==page.mainFrame());
   if(frame){
    await frame.waitForSelector('#grade .cartao');
    await frame.addStyleTag({content:`@font-face{font-family:Inter;src:url('${pathToFileURL(path.resolve('assets/Inter.ttf')).href}')}body{font-family:Inter,sans-serif}.selo-ficticio,.atualizado{display:none}.topo-fixo .dentro,main,#gestor{max-width:1660px}.cartao h3{font-size:19px}.placar b{font-size:46px}.explica,.insumos li{font-size:15px}.avisos li{font-size:16px}#hist td:hover{outline:3px solid #0b2a4f;outline-offset:2px}`});
    await frame.evaluate(()=>{
     document.querySelectorAll('.avisos li').forEach((el,i)=>el.textContent=['Crédito a classificar · exemplo fictício','Recebimento avulso · exemplo fictício','Baixa diferente do depósito · exemplo fictício'][i]);
     // Only the presentation's visual behavior is simulated; no PDF is generated here.
     document.querySelector('.topo-fixo .principal').onclick=()=>{
      const nums=[...document.querySelectorAll('.placar b')];
      nums.forEach((el,i)=>{const end=Number(el.textContent);el.textContent='0';setTimeout(()=>{const start=performance.now();function tick(now){el.textContent=String(Math.round(end*Math.min(1,(now-start)/850)));if(now-start<850)requestAnimationFrame(tick)}requestAnimationFrame(tick)},i*220)});
     };
    });
    if(scene===7) await frame.locator('.avisos').evaluate(el=>el.scrollIntoView({block:'center'}));
    // Scene 8 starts on Dia a dia; the recorded click really opens Gestor.
   }
   await page.waitForTimeout(700);
   const start=Date.now();
   await page.locator('.body').evaluate(el=>{el.style.animation='none';void el.offsetWidth;el.style.animation='appear .7s both'});
   const wait=fraction=>sleep(seconds*1000*fraction);
   const actions=async()=>{
    if(scene===4){await wait(.20);await frame.locator('.semana').hover();await wait(.12);await frame.evaluate(()=>window.scrollTo({top:510,behavior:'smooth'}));await wait(.35);await frame.evaluate(()=>window.scrollTo({top:0,behavior:'smooth'}));}
    if(scene===5){await wait(.10);await frame.locator('.topo-fixo .principal').click();await wait(.40);await frame.evaluate(()=>window.scrollTo({top:510,behavior:'smooth'}));await wait(.28);await frame.evaluate(()=>window.scrollTo({top:0,behavior:'smooth'}));}
    if(scene===8){await wait(.08);await frame.locator('#aba-gestor').click();await wait(.12);for(const cell of await frame.locator('#hist tr:nth-child(2) td').all()){await cell.hover();await wait(.045)}await page.mouse.move(1870,950);}
    if(scene===7){await wait(.25);await frame.locator('.avisos').hover();}
   };
   await Promise.all([actions(),sleep((seconds+.4)*1000)]);
   await page.screenshot({path:`build/scene${scene}.png`});
   if(scene===1 || !fs.existsSync('output/thumbnail.png')) await page.screenshot({path:'output/thumbnail.png'});
   await sleep(1000); // Quiet tail removed in composition.
   const captureSeconds=(Date.now()-start)/1000;
   const video=page.video();await context.close();
   await video.saveAs(`build/scene${scene}.webm`);
   fs.writeFileSync(`build/scene${scene}.json`,JSON.stringify({scene,seconds,captureSeconds,tail:1,errors},null,2));
   if(errors.length) throw Error(`Erro de JavaScript na cena ${scene}: ${errors.join('; ')}`);
   console.log(`Cena ${scene}: gravação concluída (${seconds}s).`);
  }
 } finally { await browser.close(); }
})().catch(e=>{console.error(e);process.exitCode=1});
