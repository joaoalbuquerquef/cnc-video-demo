"""Compose actual Playwright recordings. No browser/screenshot fallback is used."""
import json, pathlib, subprocess, sys, textwrap
R=pathlib.Path.cwd(); B=R/'build'; O=R/'output'; O.mkdir(exist_ok=True)
plans=json.loads((R/'scenes.json').read_text());mode=sys.argv[1] if len(sys.argv)>1 else '60s'
if mode not in ('60s','completo','ambos','teste'):raise ValueError(mode)
def run(cmd):subprocess.run(cmd,check=True)
def duration(p):return float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=noprint_wrappers=1:nokey=1',str(p)],text=True))
def stamp(t):
 n=round(t*1000);return f'{n//3600000:02}:{n//60000%60:02}:{n//1000%60:02},{n%1000:03}'
def subtitles(plan,name):
 cues=[];time=0
 for scene,d,parts in plan:
  texts=[]
  for part in parts:
   ls=textwrap.wrap(part,42,break_long_words=False)
   texts+=['\n'.join(ls[i:i+2]) for i in range(0,len(ls),2)]
  total=sum(len(t) for t in texts);t=time+.25
  for text in texts:
   end=t+(d-.5)*len(text)/total;cues.append((t,end,text));t=end
  time+=d
 assert all(len(l)<=42 for _,_,s in cues for l in s.splitlines())
 (O/name).write_text('\n\n'.join(f'{i+1}\n{stamp(a)} --> {stamp(b)}\n{s}' for i,(a,b,s) in enumerate(cues))+'\n')
 return time
recorded=plans['test'] if mode=='teste' else plans['short'] if mode=='60s' else plans['full']
for scene,d,_ in recorded:
 src=B/f'scene{scene}.webm';meta=json.loads((B/f'scene{scene}.json').read_text());length=duration(src)
 # Locate the beginning from the recorded tail; startup/load time is discarded.
 offset=max(0,length-meta['captureSeconds'])
 run(['ffmpeg','-hide_banner','-loglevel','error','-y','-ss',str(offset),'-i',str(src),'-t',str(d+.4),'-vf','fps=30,scale=1920:1080,setsar=1','-an','-c:v','libx264','-crf','18','-preset','veryfast','-threads','2','-pix_fmt','yuv420p',str(B/f'clip{scene}.mp4')])
def compose(plan,name,srt):
 total=subtitles(plan,srt);cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-filter_complex_threads','1'];filters=[]
 for i,(scene,d,_) in enumerate(plan):
  cmd+=['-i',str(B/f'clip{scene}.mp4')]
  filters.append(f'[{i}:v]trim=duration={d+.4},setpts=PTS-STARTPTS,fps=30,settb=AVTB,format=yuv420p[v{i}]')
 prev='v0';time=0
 for i in range(1,len(plan)):
  time+=plan[i-1][1];new=f'x{i}';filters.append(f'[{prev}][v{i}]xfade=transition=fade:duration=0.4:offset={time},fps=30,settb=AVTB[{new}]');prev=new
 filters.append(f"[{prev}]subtitles=output/{srt}:fontsdir=assets:force_style='FontName=Inter,FontSize=10,PrimaryColour=&H00FFFFFF,OutlineColour=&H004F2A0B,BackColour=&H804F2A0B,BorderStyle=3,Outline=1,Shadow=0,MarginV=27,Alignment=2'[out]")
 filterfile=B/(name+'.filter');filterfile.write_text(';'.join(filters))
 run(cmd+['-filter_complex_script',str(filterfile),'-map','[out]','-t',str(total),'-r','30','-an','-c:v','libx264','-preset','veryfast','-crf','20','-threads','2','-pix_fmt','yuv420p','-movflags','+faststart',str(O/name)])
 print('Montado:',name,flush=True)
if mode in ('60s','ambos'):compose(plans['short'],'cnc_relatorios_60s.mp4','legendas.srt')
if mode in ('completo','ambos'):compose(plans['full'],'cnc_relatorios_2min.mp4','legendas_2min.srt')
if mode=='teste':compose(plans['test'],'teste_12s.mp4','teste.srt')
